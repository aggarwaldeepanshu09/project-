import React from "react";

export default function Feed() {
  return <div className="screen-container">Feed</div>;
}
